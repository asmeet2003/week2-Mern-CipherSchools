const assert = require("assert");

describe("demo test", () => {
  it("add two numbers", () => {
    assert(2 + 3 === 5);
  });
  it("substract two numbers", () => {
    assert(1 - 1 === 0);
  });
});
